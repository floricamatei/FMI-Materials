from heapq import heappop,heappush
ls=[]
with open("profit_maxim.in") as f:
    i=0
    n=int(f.readline())
    for linie in f:
        i=i+1
        ls.append((i,[int(x) for x in linie.split()])) #profit, deadline
print(ls)
ls.sort(key=lambda a:a[1][1],reverse=True) #sortat dupa deadline descrescator
print(ls)
h=[]
j=0
planificare=[None]*n
for i in range(n,0,-1):
    while j<len(ls) and ls[j][1][1]==i:
        heappush(h,(-ls[j][1][0],ls[j][0])) #profit, indice activitate
        j+=1
    print(i)
    print(h)
    if len(h)>0:
        planificare[i-1]=heappop(h)[1]

print(planificare)
